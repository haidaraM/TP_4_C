----------------------------------------------------------------------
================================README================================
-------------------------TP4 : Binôme B3425---------------------------

-La compilation des sources s'effectue grace au makefile situé à la 
racine.
-Les tests sont effectués grace au script mktest.sh situé dans le 
répertoire /tests
-Certaines erreurs ne sont pas effectuées sur la sortie standard mais
sur la sortie d'erreur.

Bonne correction !